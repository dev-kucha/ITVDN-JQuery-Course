$( document ).ready(function() {
    //JQUERY
    $.each(array, function(i, item){

    });
    //js
    array.forEach(function(item, i){

    });

    //JQ
    $.isArray(arr);
    //JS
    array.isArray(arr);
    //JQ
    $.map(array, function(value, index){

    });
    //JS
    array.map(function(value, index){

    });
});

