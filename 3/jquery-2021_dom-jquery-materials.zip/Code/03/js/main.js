$(document).ready(function(){
//   let target = $(".target");
//   if(target.is("div")){
//       target.text("Target detected");
//   };
    // let listElements=$("li");
    // listElements.not(".active").text("Selected");
    // listElements.filter(":nth-child(2n)").text("Selected");
    // listElements.slice(2,4).text("Sliced");
    // listElements.first().text("Selected");
    // listElements.last().text("Selected");
    // let findContainer = $(".text-container").has("span");
    // if(findContainer.length>0){
    //     $("span").text("Has container");
    // }

    // $(".row").unwrap();
    // $(".wrapMe").wrap("<div class='block'></div>");
    // $('.text').wrapInner("<div class='block'></div>");
    // $(".text").wrapAll("<div class='block'></div>");
    // $(".children").children().text("Selected");
    // $("span").closest("p").text("Selected");
    // $("ul").find("span").text("Finded!");
    // $(".active").next().text("Next");
    // $(".active").nextUntil(".stop").text("Next");
    // $(".active").nextAll().text("Next");
    // $(".text-block").offsetParent().text("Offset!");
    // console.log($(".block span").parents());
    // console.log($(".block span").parentsUntil("div"));
    // $(".active").prev().text("Prev");
    // $(".stop").prevAll().text("Prev all");
    // $(".stop").prevUntil(".active").text("Prev all");
    // $(".active").siblings().text("Siblings!");
    $("li").slice(2).text("Slice");
}); 